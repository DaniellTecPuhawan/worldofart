// src/App.js

import React, { useState, useEffect } from 'react';
import Image from '../components/uploadPhoto';

const App = () => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    fetchImages();
  }, []);

  const fetchImages = async () => {
    try {
      const response = await fetch('/wofdata');
      if (!response.ok) {
        throw new Error('Error fetching images');
      }
      const data = await response.json();
      setImages(data);
    } catch (error) {
      console.error('Error fetching images:', error);
    }
  };

  return (
    <div>
      <h1>Images</h1>
      {images.map(image => (
        <Image
          key={image._id}
          name={image.name}
          description={image.title}
          imageUrl={`/server/images/${image.imageUrl}`}
        />
      ))}
    </div>
  );
};

export default App;
