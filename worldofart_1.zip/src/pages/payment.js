import React from 'react';
import '../css/Payment.scss';
import MainScreen from '../components/screens/MainScreen'

function Payment() {
       return <MainScreen />
}

export default Payment;