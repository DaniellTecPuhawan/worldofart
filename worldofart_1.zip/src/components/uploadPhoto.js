// src/components/Image.js

import React from 'react';

const Image = ({ name, title, imageUrl }) => {
  return (
    <div>
      <h3>{name}</h3>
      <p>{title}</p>
      <img src={imageUrl} alt={name} style={{ width: '300px', height: 'auto' }} />
    </div>
  );
};

export default Image;
