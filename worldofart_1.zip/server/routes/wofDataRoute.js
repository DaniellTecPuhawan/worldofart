// routes/imageRoutes.js

const express = require('express');
const router = express.Router();
const imageController = require('./wofDataRoute');
const multer = require('multer');

// Configuración de multer para manejar el almacenamiento de imágenes
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, '/server/images');
  },
  filename: function(req, file, cb) {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

// Ruta para subir una imagen y crear un nuevo documento
router.post('/wofdata', upload.single('image'), imageController.uploadImage);

// Ruta para obtener todas las imágenes
router.get('/', imageController.getImages);

module.exports = router;
