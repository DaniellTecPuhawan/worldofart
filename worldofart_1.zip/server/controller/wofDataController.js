// controllers/imageController.js

const Image = require('../models/wofDataModel');

// Función para subir una imagen y crear un nuevo documento
exports.uploadImage = async (req, res) => {
  try {
    const { name, description } = req.body;
    const imageUrl = req.file.path; // La ruta de la imagen se almacena en req.file.path
    const newImage = new Image({ name, description, imageUrl });
    const savedImage = await newImage.save();
    res.status(201).json(savedImage);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Función para obtener todas las imágenes
exports.getImages = async (req, res) => {
  try {
    const images = await Image.find();
    res.json(images);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
