require('dotenv').config()

const express = require('express');
const mongoose = require('mongoose');

//const app = express() //express app
const wofDataRoutes = require('./routes/wofDataRoute') //Routes

//express app

const app = express ()
const PORT = process.env.PORT || 8000;


//middleware

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/server/images', express.static('uploads'));
//msg
app.get('/', (req, res) => {
    res.json({mssg:'Server ON'})
})

//routes
app.use('/wofData', wofDataRoutes)

// Manejo de errores
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
  });

//connect db
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        //requests
        app.listen(process.env.PORT, () => {
            console.log('Listen port:', 'http://localhost:' + process.env.PORT)
        })
    })
    .catch((error) => {
        console.log(error)
    })

//requests
//app.listen(process.env.PORT, () => {
  //  console.log('Listen port:', process.env.PORT)
//})

const itemSchema = new mongoose.Schema({
    name: String,
    title: String,
    story: String,
    type: String,
    range: String,
    movementSpeed: String,
    enchantment: String,

    imageUrl: String
});

const Item = mongoose.model('Item', itemSchema);
app.use(express.json());
  
  // Ruta para obtener todas los elementos
  app.get('/wofdata', async (req, res) => {
    try {
      const items = await Item.find();
      res.json(items);
    } catch (error) {
      console.error('Error fetching items:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Ruta para agregar un nuevo elemento
  app.post('/wofdata', async (req, res) => {
    try {
      const { name, title, imageUrl } = req.body;
      const newItem = new Item({ name, description, imageUrl });
      await newItem.save();
      res.json(newItem);
    } catch (error) {
      console.error('Error creating item:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
