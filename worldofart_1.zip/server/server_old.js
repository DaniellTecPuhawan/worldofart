require('dotenv').config()

const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const bodyParser = require('body-parser');
const imgSchema = require('./controller/wofDataController');



//const app = express() //express app
const wofDataRoutes = require('./routes/wofDataRoute') //Routes

//express app

const app = express ()
const PORT = process.env.PORT || 8000;
//middleware

app.use(express.json())
app.set("view engine", "ejs");

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use((req,res, next) => {
    console.log(req.path, req.method)
    next()
})

//msg
app.get('/', (req, res) => {
    res.json({mssg:'Server ON'})
})

//routes
app.use('/wofData', wofDataRoutes)

app.use('/wofdata', express.static('wofdata'));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, '/tmp/my-uploads')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
        cb(null, file.fieldname + '-' + Date.now())
    }
});
  
const upload = multer({ storage: storage });

app.post("/upload-image", upload.single("image"), async(req, res) => {
    console.log(req.body)
    res.send("Upload")
})

app.use(express.json());

app.post('/wofdata', upload.single('image'), (req, res, next) => {
 
    var obj = {
        name: req.body.name,
        desc: req.body.desc,
        img: {
            data: fs.readFileSync(path.join(__dirname + '/server/upload' + req.file.filename)),
            contentType: 'image/png'
        }
    }
    imgSchema.create(obj)
    .then ((err, item) => {
        if (err) {
            console.log(err);
        }
        else {
            // item.save();
            res.redirect('/');
        }
    });
});
  // Ruta para agregar un nuevo elemento
  app.post('/wofdata', async (req, res) => {
    try {
      const { name, description, image } = req.body;
      const newItem = new Item({ name, description, image });
      await newItem.save();
      res.json(newItem);
    } catch (error) {
      console.error('Error creating item:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });


//connect db
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        //requests
        app.listen(process.env.PORT, () => {
            console.log('Listen port:', 'http://localhost:' + process.env.PORT)
        })
    })
    .catch((error) => {
        console.log(error)
    })

//requests
//app.listen(process.env.PORT, () => {
  //  console.log('Listen port:', process.env.PORT)
//})

const itemSchema = new mongoose.Schema({
    name: String,
    title: String,
    story: String,
    type: String,
    range: String,
    movementSpeed: String,
    enchantment: String,

    image: String
});

const Item = mongoose.model('Item', itemSchema);